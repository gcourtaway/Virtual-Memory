#ifndef TESTS_MAIN_H
#define TESTS_MAIN_H

void test_main (void);

#endif /* tests/main.h */
